import Grandson from "./Grandson"

const Son = () => {
    return <Grandson/>
}

export default Son