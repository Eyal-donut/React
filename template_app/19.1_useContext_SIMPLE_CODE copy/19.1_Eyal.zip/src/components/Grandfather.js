import Father from "./Father";

const Grandfather = () => {
  return <Father />;
};

export default Grandfather;
