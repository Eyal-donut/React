import Grandfather from "./components/Grandfather";

const App = () => {
  return <Grandfather />;
};
export default App;
